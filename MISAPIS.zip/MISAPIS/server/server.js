import express from 'express';
import cors from 'cors';
import indexRoutes from '../routes/index.routes.js';
import *as db from '../db/cnn_mongodb.js'

export default class Server{
    constructor(){
        this.app = express();
        this.port = process.env.PORT  || 3000;
        this.generalRoute= '/api/';

        this.conectarDBMongo();
        //Middlewares
        this.middlewares();

        //rutas de mi aplicacion
        this.routes();
    
    }
async conectarDBMongo(){
    if(!db.isConnected){
        await db.conectarAMongoDB();
    }
}


    middlewares(){
        //CORS
        this.app.use(cors());
        
        // Lectura y parseo del body
        this.app.use(express.json());
        // Directorio publico
        this.app.use(express.static('public'));
    }
    routes(){
       // local.host:000/api/ejemplo
         this.app.use(this.generalRoute, indexRoutes);
         this.app.use('**',(req,res) => {
            res.status(400).json({
                msg: 'Rutas no encontrada'
            });
         })
    }
    listen(){
        this.app.listen(this.port, () => {
            console.log('servidor corriendo en puerto', `${this.port}`.yellow);
        })
    }
}